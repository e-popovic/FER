<?php
$dom = new DOMDocument();
$dom->load("podaci.xml");
$xpath = new DOMXPath($dom);
$xpath->registerNamespace('php','http://php.net/xpath');
$xpath->registerPHPFunctions();

function stvoriFilter(){
	$filter[]=array();
	$i=0;
	
	//contains -- prvo iz xml, drugo iz trazilice
	if(isset($_REQUEST['ime'])){
		$filter[$i] = "[ime[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['ime'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['prezime'])){
		$filter[$i] = "[prezime[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['prezime'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['godinar'])){
		if ($_GET['godinar'] != "odaberi"){
			$filter[$i] = "[godinar[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['godinar'])."')]]";	
			$i++;
		}
	}
	
	if(isset($_REQUEST['govpodrucje'])){
		if ($_GET['govpodrucje'] == 'englesko'){
			$filter[$i] = "[drzavarod/@govpodrucje='englesko']";
			$i++;
		}
		else {
			$filter[$i] = "[drzavarod/@govpodrucje='drugo']";
			$i++;
		}
	}
	
	if(isset($_REQUEST['mjestorod'])){
		$filter[$i] = "[mjestorod[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['mjestorod'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['drzavarod'])){
		$filter[$i] = "[drzavarod[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['drzavarod'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['nagrade'])){
		$filter[$i]="[nagrade[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['nagrade'])."')]]";
		$i++;
	}
	
	if(isset($_REQUEST['nominacije'])){
		$filter[$i]="[nominacije[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['nominacije'])."')]]";
		$i++;
	}
	
	if(isset($_REQUEST['wiki'])){
		$filter[$i] = "[wiki[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['wiki'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['id'])){
		$filter[$i] = "[contains(@id,'".mb_strtolower($_GET['id'])."')]";	
		$i++;
	}
	
	if(isset($_REQUEST['hrnaslov'])){
		$filter[$i] = "[film/naslov/hrnaslov[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['hrnaslov'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['engnaslov'])){
		$filter[$i] = "[film/naslov/engnaslov[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['engnaslov'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['nije_eng'])){
		if(isset($_REQUEST['izvnaslov'])){
			$filter[$i] = "[film/naslov/izvnaslov[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['izvnaslov'])."')]]";	
			$i++;
		}
	}
	
	if(isset($_REQUEST['godinaf'])){
		if ($_GET['godinaf'] != "odaberi"){
			$filter[$i] = "[film/godinaf[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['godinaf'])."')]]";	
			$i++;
		}
	}
	
	if(isset($_REQUEST['najbolji'])){
		$filter[$i] = "[film[boolean(najbolji)]]";	
		$i++;
	}
	
	if(isset($_REQUEST['jezik'])){
		$filter[$i] = "[film/jezik[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($_GET['jezik'])."')]]";	
		$i++;
	}
	
	if(isset($_REQUEST['zanr'])){
		$zanrovi=$_REQUEST['zanr'];
		$brzanrova=count($zanrovi);
		$filter[$i] = "[film[zanr[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($zanrovi[0])."')]]";
		for ($x=1; $x<$brzanrova; $x++){
			$filter[$i].=" and film[zanr[contains(php:functionString('mb_strtolower',text()),'".mb_strtolower($zanrovi[$x])."')]]";
		}
		$filter[$i].="]";
		
		$i++;
	}
	
	//prebaci ih sve u jedan filter string
	$sfilter="";
	for ($x=0; $x<$i; $x++){
		$sfilter.=$filter[$x];
	}
	return $sfilter;
}

?>